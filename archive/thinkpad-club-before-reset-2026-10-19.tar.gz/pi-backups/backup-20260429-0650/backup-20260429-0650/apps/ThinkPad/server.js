const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const os = require('os');

// --- Binary-safe multipart parser ---
function parseMultipart(req, boundary, callback) {
  const chunks = [];
  req.on('data', chunk => chunks.push(chunk));
  req.on('end', () => {
    const buffer = Buffer.concat(chunks);
    const boundaryBuffer = Buffer.from(boundary);
    const parts = [];

    let start = buffer.indexOf(boundaryBuffer);
    if (start === -1) return callback({ filename: null, fileBuffer: null });

    while (start !== -1) {
      const end = buffer.indexOf(boundaryBuffer, start + boundaryBuffer.length);
      if (end === -1) break;
      parts.push(buffer.slice(start + boundaryBuffer.length, end));
      start = end;
    }

    let filename = null;
    let fileBuffer = null;
    let originalFilename = null;
    let printer = null;
    let stuffName = null;
    let url = null;
    let name = null;
    let isYouTube = null;

    parts.forEach(part => {
      const headerEnd = part.indexOf('\r\n\r\n');
      if (headerEnd === -1) return;

      const header = part.slice(0, headerEnd).toString();
      const body = part.slice(headerEnd + 4, part.length - 2);

      if (header.includes('name="filename"')) {
        filename = body.toString().trim();
      }
      if (header.includes('name="printer"')) {
        printer = body.toString().trim();
      }
      if (header.includes('name="stuffName"')) {
        stuffName = body.toString().trim();
      }
      if (header.includes('name="url"')) {
        url = body.toString().trim();
      }
      if (header.includes('name="name"')) {
        name = body.toString().trim();
      }
      if (header.includes('name="isYouTube"')) {
        isYouTube = body.toString().trim();
      }
      if (header.includes('name="file"') || header.includes('name="imageFile"')) {
        fileBuffer = body;
        // Try to extract original filename from Content-Disposition header
        const filenameMatch = header.match(/filename="([^"]+)"/);
        if (filenameMatch) {
          originalFilename = filenameMatch[1];
        }
      }
    });

    // Use provided filename if not empty, otherwise use original filename, or generate one
    const finalFilename = (filename && filename.length > 0) ? filename : (originalFilename || `upload-${Date.now()}.jpg`);

    callback({ filename: finalFilename, fileBuffer, printer: printer, stuffName, url, name, isYouTube });
  });
}

// --- WEBCAM CAPTURE FUNCTION ---
function captureWebcam(callback) {
  const homeDir = os.homedir();
  const webcamDir = path.join(homeDir, 'Pictures', 'Webcam');
  const archiveDir = path.join(webcamDir, 'archive');
  const currentImagePath = path.join(webcamDir, 'current.jpg');
  
  // Ensure directories exist
  if (!fs.existsSync(webcamDir)) {
    fs.mkdirSync(webcamDir, { recursive: true });
  }
  if (!fs.existsSync(archiveDir)) {
    fs.mkdirSync(archiveDir, { recursive: true });
  }
  
  // Archive the old current.jpg if it exists
  if (fs.existsSync(currentImagePath)) {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const archiveFilename = `current-${timestamp}.jpg`;
    const archivePath = path.join(archiveDir, archiveFilename);
    
    fs.renameSync(currentImagePath, archivePath);
    console.log(`Archived previous image to ${archivePath}`);
  }
  
  // Use fswebcam to capture image directly to current.jpg
  // -r 1280x720: resolution (adjust as needed)
  // --no-banner: remove timestamp banner
  // -S 2: skip 2 frames to let camera adjust
  const command = `fswebcam -r 1280x720 --no-banner -S 2 "${currentImagePath}"`;
  
  exec(command, (error, stdout, stderr) => {
    if (error) {
      console.error(`Webcam capture error: ${error.message}`);
      return callback({ success: false, error: error.message, stderr });
    }
    callback({ success: true, filename: 'current.jpg', filepath: currentImagePath });
  });
}

// --- HTTP SERVER ---
const server = http.createServer((req, res) => {

  // --- WEBCAM CAPTURE ENDPOINT ---
  if (req.url === '/capture' && req.method === 'GET') {
    captureWebcam((result) => {
      if (result.success) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ 
          success: true, 
          message: 'Webcam image captured successfully',
          filename: result.filename,
          filepath: result.filepath
        }));
      } else {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ 
          success: false, 
          error: result.error || 'Failed to capture webcam image',
          stderr: result.stderr
        }));
      }
    });
    return;
  }

  // --- CURRENT WEBCAM IMAGE ENDPOINT ---
  if (req.url.startsWith('/webcam/current.jpg') && req.method === 'GET') {
    const homeDir = os.homedir();
    const currentImagePath = path.join(homeDir, 'Pictures', 'Webcam', 'current.jpg');
    
    fs.readFile(currentImagePath, (err, data) => {
      if (err) {
        res.writeHead(404);
        return res.end('No webcam image found');
      }
      // Add no-cache headers to prevent browser caching
      res.writeHead(200, { 
        'Content-Type': 'image/jpeg',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      });
      res.end(data);
    });
    return;
  }

  // --- PRINT FILE ENDPOINT ---
  if (req.url === '/print' && req.method === 'POST') {
    const contentType = req.headers['content-type'];
    const boundaryMatch = contentType.match(/boundary=(.+)$/);

    if (!boundaryMatch) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ success: false, error: 'No multipart boundary found.' }));
    }

    const boundary = '--' + boundaryMatch[1];

    parseMultipart(req, boundary, ({ filename, fileBuffer, printer }) => {
      if (!fileBuffer) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ success: false, error: 'Missing file data.' }));
      }

      // Get printer name if provided
      let printerName = null;
      if (printer && printer.trim()) {
        printerName = printer.trim();
      }

      // Use original filename if available, otherwise generate one
      const originalFilename = filename || 'file';
      
      // Preserve file extension for proper file type detection by CUPS
      const ext = path.extname(originalFilename);
      const baseName = path.basename(originalFilename, ext) || 'file';
      // Sanitize filename but keep extension
      const safeBaseName = baseName.replace(/[^a-zA-Z0-9._-]/g, '_');
      const safeFilename = safeBaseName + (ext || '');

      // Create temporary file for printing
      const tempDir = os.tmpdir();
      const tempFilename = `print-${Date.now()}-${safeFilename}`;
      const tempPath = path.join(tempDir, tempFilename);

      // Write file to temp directory
      fs.writeFile(tempPath, fileBuffer, (err) => {
        if (err) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ success: false, error: 'Failed to save file for printing.' }));
        }

        // Build lp command with proper printer specification
        let lpCommand = 'lp';
        if (printerName) {
          lpCommand += ` -d "${printerName}"`;
        }
        // Add the file path
        lpCommand += ` "${tempPath}"`;

        console.log(`Printing file: ${tempPath} to printer: ${printerName || 'default'}`);

        // Execute print command
        exec(lpCommand, { timeout: 30000 }, (error, stdout, stderr) => {
          // Clean up temp file after a delay to ensure print job is queued
          setTimeout(() => {
            fs.unlink(tempPath, (unlinkErr) => {
              if (unlinkErr) {
                console.error(`Failed to delete temp file: ${unlinkErr.message}`);
              }
            });
          }, 2000);

          if (error) {
            console.error(`Print error: ${error.message}`, stderr);
            res.writeHead(500, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ 
              success: false, 
              error: `Print failed: ${error.message}`,
              stderr: stderr ? stderr.toString() : ''
            }));
          }

          // Extract job ID from stdout if available
          const jobMatch = stdout.match(/request id is (.+?) \(/);
          const jobId = jobMatch ? jobMatch[1] : null;

          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ 
            success: true, 
            message: `Print job submitted successfully.${jobId ? ` Job ID: ${jobId}` : ''}`,
            jobId: jobId
          }));
        });
      });
    });
    return;
  }

  // --- FILE UPLOAD ENDPOINT ---
  if (req.url === '/upload' && req.method === 'POST') {
    const contentType = req.headers['content-type'];
    const boundaryMatch = contentType.match(/boundary=(.+)$/);

    if (!boundaryMatch) {
      res.writeHead(400);
      return res.end('No multipart boundary found.');
    }

    const boundary = '--' + boundaryMatch[1];

    parseMultipart(req, boundary, ({ filename, fileBuffer }) => {
      if (!filename || !fileBuffer) {
        res.writeHead(400);
        return res.end('Missing filename or file data.');
      }

      // Validate it's an image file
      const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.svg'];
      const ext = path.extname(filename).toLowerCase();
      if (!imageExtensions.includes(ext)) {
        res.writeHead(400);
        return res.end('Only image files are allowed.');
      }

      // Save to Pictures/Uploads directory
      const homeDir = os.homedir();
      const uploadsDir = path.join(homeDir, 'Pictures', 'Uploads');
      
      // Ensure directory exists
      if (!fs.existsSync(uploadsDir)) {
        fs.mkdirSync(uploadsDir, { recursive: true });
      }

      const savePath = path.join(uploadsDir, filename);

      fs.writeFile(savePath, fileBuffer, err => {
        if (err) {
          res.writeHead(500);
          return res.end('Failed to save file.');
        }

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, filename: filename }));
      });
    });
    return;
  }

  // --- LIST UPLOADED IMAGES ENDPOINT ---
  if (req.url === '/uploads/list' && req.method === 'GET') {
    const homeDir = os.homedir();
    const uploadsDir = path.join(homeDir, 'Pictures', 'Uploads');
    
    if (!fs.existsSync(uploadsDir)) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ images: [] }));
    }

    fs.readdir(uploadsDir, (err, files) => {
      if (err) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: 'Error reading uploads directory' }));
      }

      const imageFiles = files
        .filter(file => {
          const ext = path.extname(file).toLowerCase();
          return ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.svg'].includes(ext);
        })
        .map(file => ({
          filename: file,
          path: path.join(uploadsDir, file),
          time: fs.statSync(path.join(uploadsDir, file)).mtime.getTime()
        }))
        .sort((a, b) => b.time - a.time); // Sort newest first

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ images: imageFiles.map(img => img.filename) }));
    });
    return;
  }

  // --- SERVE UPLOADED IMAGE ---
  if (req.url.startsWith('/uploads/image/') && req.method === 'GET') {
    let filename = req.url.replace('/uploads/image/', '');
    // Decode URL-encoded filename
    try {
      filename = decodeURIComponent(filename);
    } catch (e) {
      // If decoding fails, use as-is
    }
    
    // Security: validate filename (no path traversal)
    if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
      res.writeHead(400);
      return res.end('Invalid filename');
    }

    const homeDir = os.homedir();
    const imagePath = path.join(homeDir, 'Pictures', 'Uploads', filename);

    fs.readFile(imagePath, (err, data) => {
      if (err) {
        res.writeHead(404);
        return res.end('Image not found');
      }

      const ext = path.extname(filename).toLowerCase();
      const mime = {
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.png': 'image/png',
        '.gif': 'image/gif',
        '.webp': 'image/webp',
        '.bmp': 'image/bmp',
        '.svg': 'image/svg+xml',
        '.heic': 'image/heic',
        '.heif': 'image/heif'
      }[ext] || 'image/jpeg';

      // Add headers to help with color display and prevent caching issues
      res.writeHead(200, { 
        'Content-Type': mime,
        'Cache-Control': 'public, max-age=31536000', // Cache for 1 year
        'Accept-Ranges': 'bytes'
      });
      res.end(data);
    });
    return;
  }

  // --- DELETE UPLOADED IMAGE ---
  if (req.url.startsWith('/uploads/delete/') && req.method === 'DELETE') {
    let filename = req.url.replace('/uploads/delete/', '');
    // Decode URL-encoded filename
    try {
      filename = decodeURIComponent(filename);
    } catch (e) {
      // If decoding fails, use as-is
    }
    
    // Security: validate filename (no path traversal)
    if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ success: false, error: 'Invalid filename' }));
    }

    const homeDir = os.homedir();
    const imagePath = path.join(homeDir, 'Pictures', 'Uploads', filename);

    fs.unlink(imagePath, (err) => {
      if (err) {
        if (err.code === 'ENOENT') {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ success: false, error: 'Image not found' }));
        }
        res.writeHead(500, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ success: false, error: 'Failed to delete image' }));
      }

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, message: 'Image deleted successfully' }));
    });
    return;
  }

  // --- SCRATCH GAMES LIST ENDPOINT ---
  if (req.url === '/scratch/list' && req.method === 'GET') {
    const scratchDataPath = path.join(__dirname, 'scratch-games.json');
    
    fs.readFile(scratchDataPath, 'utf8', (err, data) => {
      if (err) {
        // If file doesn't exist, return empty array
        if (err.code === 'ENOENT') {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ games: [] }));
        }
        res.writeHead(500, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: 'Error reading scratch games' }));
      }

      try {
        const games = JSON.parse(data);
        // Sort by timestamp, newest first
        games.sort((a, b) => b.timestamp - a.timestamp);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ games }));
      } catch (parseErr) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Error parsing scratch games data' }));
      }
    });
    return;
  }

  // --- SCRATCH GAME SUBMISSION ENDPOINT ---
  if (req.url === '/scratch/submit' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      try {
        const gameData = JSON.parse(body);
        const { gameName, url, name } = gameData;

        if (!gameName || !url || !name) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ success: false, error: 'Missing game name, URL, or author name' }));
        }

        // Validate Scratch URL
        if (!url.includes('scratch.mit.edu/projects/')) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ success: false, error: 'Invalid Scratch URL' }));
        }

        const scratchDataPath = path.join(__dirname, 'scratch-games.json');
        
        // Read existing games
        fs.readFile(scratchDataPath, 'utf8', (err, data) => {
          let games = [];
          if (!err) {
            try {
              games = JSON.parse(data);
            } catch (parseErr) {
              // If parse fails, start with empty array
              games = [];
            }
          }

          // Add new game
          games.push({
            gameName: gameName.trim(),
            url: url.trim(),
            name: name.trim(),
            timestamp: Date.now()
          });

          // Write back to file
          fs.writeFile(scratchDataPath, JSON.stringify(games, null, 2), (writeErr) => {
            if (writeErr) {
              res.writeHead(500, { 'Content-Type': 'application/json' });
              return res.end(JSON.stringify({ success: false, error: 'Failed to save game' }));
            }

            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: true }));
          });
        });
      } catch (parseErr) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: 'Invalid JSON data' }));
      }
    });
    return;
  }

  // --- SCRATCH GAME DELETE ENDPOINT ---
  if (req.url === '/scratch/delete' && req.method === 'DELETE') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      try {
        const deleteData = JSON.parse(body);
        const { url, timestamp } = deleteData;

        if (!url || !timestamp) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ success: false, error: 'Missing URL or timestamp' }));
        }

        const scratchDataPath = path.join(__dirname, 'scratch-games.json');
        
        // Read existing games
        fs.readFile(scratchDataPath, 'utf8', (err, data) => {
          if (err) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ success: false, error: 'Games file not found' }));
          }

          try {
            let games = JSON.parse(data);
            
            // Find and remove the game matching URL and timestamp
            const initialLength = games.length;
            const timestampNum = Number(timestamp);
            games = games.filter(game => !(game.url === url && Number(game.timestamp) === timestampNum));
            
            if (games.length === initialLength) {
              res.writeHead(404, { 'Content-Type': 'application/json' });
              return res.end(JSON.stringify({ success: false, error: 'Game not found' }));
            }

            // Write back to file
            fs.writeFile(scratchDataPath, JSON.stringify(games, null, 2), (writeErr) => {
              if (writeErr) {
                res.writeHead(500, { 'Content-Type': 'application/json' });
                return res.end(JSON.stringify({ success: false, error: 'Failed to delete game' }));
              }

              res.writeHead(200, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ success: true, message: 'Game deleted successfully' }));
            });
          } catch (parseErr) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ success: false, error: 'Error parsing games data' }));
          }
        });
      } catch (parseErr) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: 'Invalid JSON data' }));
      }
    });
    return;
  }

  // --- SCRATCH PAGE ---
  if (req.url === '/scratch' && req.method === 'GET') {
    const scratchPagePath = path.join(__dirname, 'scratch.html');
    fs.readFile(scratchPagePath, (err, data) => {
      if (err) {
        res.writeHead(404);
        return res.end('Scratch page not found');
      }
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(data);
    });
    return;
  }

  // --- UPLOADS PAGE ---
  if (req.url === '/uploads' && req.method === 'GET') {
    const uploadsPagePath = path.join(__dirname, 'uploads.html');
    fs.readFile(uploadsPagePath, (err, data) => {
      if (err) {
        res.writeHead(404);
        return res.end('Uploads page not found');
      }
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(data);
    });
    return;
  }

  // --- MUSIC LIST ENDPOINT ---
  if (req.url === '/music/list' && req.method === 'GET') {
    const musicDataPath = path.join(__dirname, 'music.json');
    
    fs.readFile(musicDataPath, 'utf8', (err, data) => {
      if (err) {
        // If file doesn't exist, return empty array
        if (err.code === 'ENOENT') {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ music: [] }));
        }
        res.writeHead(500, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: 'Error reading music' }));
      }

      try {
        const music = JSON.parse(data);
        // Sort by timestamp, newest first
        music.sort((a, b) => b.timestamp - a.timestamp);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ music }));
      } catch (parseErr) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Error parsing music data' }));
      }
    });
    return;
  }

  // --- MUSIC SUBMISSION ENDPOINT ---
  if (req.url === '/music/submit' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      try {
        const musicData = JSON.parse(body);
        const { musicName, url, name } = musicData;

        if (!url) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ success: false, error: 'Missing URL' }));
        }

        // Basic URL validation
        try {
          new URL(url);
        } catch (e) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ success: false, error: 'Invalid URL' }));
        }

        const musicDataPath = path.join(__dirname, 'music.json');
        
        // Read existing music
        fs.readFile(musicDataPath, 'utf8', (err, data) => {
          let music = [];
          if (!err) {
            try {
              music = JSON.parse(data);
            } catch (parseErr) {
              // If parse fails, start with empty array
              music = [];
            }
          }

          // Add new music
          music.push({
            musicName: (musicName || '').trim(),
            url: url.trim(),
            name: (name || '').trim(),
            timestamp: Date.now()
          });

          // Write back to file
          fs.writeFile(musicDataPath, JSON.stringify(music, null, 2), (writeErr) => {
            if (writeErr) {
              res.writeHead(500, { 'Content-Type': 'application/json' });
              return res.end(JSON.stringify({ success: false, error: 'Failed to save music' }));
            }

            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: true }));
          });
        });
      } catch (parseErr) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: 'Invalid JSON data' }));
      }
    });
    return;
  }

  // --- MUSIC DELETE ENDPOINT ---
  if (req.url === '/music/delete' && req.method === 'DELETE') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      try {
        const deleteData = JSON.parse(body);
        const { url, timestamp } = deleteData;

        if (!url || !timestamp) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ success: false, error: 'Missing URL or timestamp' }));
        }

        const musicDataPath = path.join(__dirname, 'music.json');
        
        // Read existing music
        fs.readFile(musicDataPath, 'utf8', (err, data) => {
          if (err) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ success: false, error: 'Music file not found' }));
          }

          try {
            let music = JSON.parse(data);
            
            // Find and remove the music matching URL and timestamp
            const initialLength = music.length;
            const timestampNum = Number(timestamp);
            music = music.filter(item => !(item.url === url && Number(item.timestamp) === timestampNum));
            
            if (music.length === initialLength) {
              res.writeHead(404, { 'Content-Type': 'application/json' });
              return res.end(JSON.stringify({ success: false, error: 'Music not found' }));
            }

            // Write back to file
            fs.writeFile(musicDataPath, JSON.stringify(music, null, 2), (writeErr) => {
              if (writeErr) {
                res.writeHead(500, { 'Content-Type': 'application/json' });
                return res.end(JSON.stringify({ success: false, error: 'Failed to delete music' }));
              }

              res.writeHead(200, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ success: true, message: 'Music deleted successfully' }));
            });
          } catch (parseErr) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ success: false, error: 'Error parsing music data' }));
          }
        });
      } catch (parseErr) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: 'Invalid JSON data' }));
      }
    });
    return;
  }

  // --- MUSIC PAGE ---
  if (req.url === '/music' && req.method === 'GET') {
    const musicPagePath = path.join(__dirname, 'music.html');
    fs.readFile(musicPagePath, (err, data) => {
      if (err) {
        res.writeHead(404);
        return res.end('Music page not found');
      }
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(data);
    });
    return;
  }

  // --- STUFF LIST ENDPOINT ---
  if (req.url === '/stuff/list' && req.method === 'GET') {
    const stuffDataPath = path.join(__dirname, 'stuff.json');
    
    fs.readFile(stuffDataPath, 'utf8', (err, data) => {
      if (err) {
        // If file doesn't exist, return empty array
        if (err.code === 'ENOENT') {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ stuff: [] }));
        }
        res.writeHead(500, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: 'Error reading stuff' }));
      }

      try {
        const stuff = JSON.parse(data);
        // Sort by timestamp, newest first
        stuff.sort((a, b) => b.timestamp - a.timestamp);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ stuff }));
      } catch (parseErr) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Error parsing stuff data' }));
      }
    });
    return;
  }

  // --- STUFF SUBMISSION ENDPOINT ---
  if (req.url === '/stuff/submit' && req.method === 'POST') {
    const contentType = req.headers['content-type'] || '';
    
    // Check if it's multipart/form-data (file upload)
    if (contentType.includes('multipart/form-data')) {
      const boundaryMatch = contentType.match(/boundary=(.+)$/);
      if (!boundaryMatch) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ success: false, error: 'No multipart boundary found' }));
      }

      const boundary = '--' + boundaryMatch[1];
      
      parseMultipart(req, boundary, ({ filename, fileBuffer, stuffName, url, name, isYouTube }) => {
        if (!url) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ success: false, error: 'Missing URL' }));
        }

        // Basic URL validation
        try {
          new URL(url);
        } catch (e) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ success: false, error: 'Invalid URL' }));
        }

        // If marked as YouTube, validate it's actually a YouTube URL
        const isYouTubeBool = isYouTube === 'true' || isYouTube === true;
        if (isYouTubeBool && !url.includes('youtube.com') && !url.includes('youtu.be')) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ success: false, error: 'Invalid YouTube URL' }));
        }

        let imageUrl = '';
        
        // If file was uploaded, save it
        if (fileBuffer && filename) {
          const homeDir = os.homedir();
          const stuffImagesDir = path.join(homeDir, 'Pictures', 'Stuff');
          
          // Ensure directory exists
          if (!fs.existsSync(stuffImagesDir)) {
            fs.mkdirSync(stuffImagesDir, { recursive: true });
          }

          // Generate unique filename
          const ext = path.extname(filename) || '.jpg';
          const timestamp = Date.now();
          const safeFilename = `stuff-${timestamp}${ext}`;
          const savePath = path.join(stuffImagesDir, safeFilename);

          fs.writeFile(savePath, fileBuffer, (err) => {
            if (err) {
              res.writeHead(500, { 'Content-Type': 'application/json' });
              return res.end(JSON.stringify({ success: false, error: 'Failed to save image' }));
            }

            imageUrl = `/stuff/image/${safeFilename}`;
            saveStuffItem(stuffName, url, name, isYouTubeBool, imageUrl, res);
          });
        } else {
          saveStuffItem(stuffName, url, name, isYouTubeBool, imageUrl, res);
        }
      });
      return;
    } else {
      // JSON submission (URL-based image)
      let body = '';
      req.on('data', chunk => {
        body += chunk.toString();
      });
      req.on('end', () => {
        try {
          const stuffData = JSON.parse(body);
          const { stuffName, url, name, isYouTube, imageUrl } = stuffData;

          if (!url) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ success: false, error: 'Missing URL' }));
          }

          // Basic URL validation
          try {
            new URL(url);
          } catch (e) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ success: false, error: 'Invalid URL' }));
          }

          // If marked as YouTube, validate it's actually a YouTube URL
          if (isYouTube && !url.includes('youtube.com') && !url.includes('youtu.be')) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ success: false, error: 'Invalid YouTube URL' }));
          }

          saveStuffItem(stuffName, url, name, isYouTube !== false, imageUrl || '', res);
        } catch (parseErr) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: 'Invalid JSON data' }));
        }
      });
      return;
    }
  }

  // Helper function to save stuff item
  function saveStuffItem(stuffName, url, name, isYouTube, imageUrl, res) {
    const stuffDataPath = path.join(__dirname, 'stuff.json');
    
    // Read existing stuff
    fs.readFile(stuffDataPath, 'utf8', (err, data) => {
      let stuff = [];
      if (!err) {
        try {
          stuff = JSON.parse(data);
        } catch (parseErr) {
          // If parse fails, start with empty array
          stuff = [];
        }
      }

      // Add new stuff
      stuff.push({
        stuffName: (stuffName || '').trim(),
        url: url.trim(),
        name: (name || '').trim(),
        isYouTube: isYouTube,
        imageUrl: imageUrl,
        timestamp: Date.now()
      });

      // Write back to file
      fs.writeFile(stuffDataPath, JSON.stringify(stuff, null, 2), (writeErr) => {
        if (writeErr) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ success: false, error: 'Failed to save' }));
        }

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true }));
      });
    });
  }

  // --- STUFF DELETE ENDPOINT ---
  if (req.url === '/stuff/delete' && req.method === 'DELETE') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      try {
        const deleteData = JSON.parse(body);
        const { url, timestamp } = deleteData;

        if (!url || !timestamp) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ success: false, error: 'Missing URL or timestamp' }));
        }

        const stuffDataPath = path.join(__dirname, 'stuff.json');
        
        // Read existing stuff
        fs.readFile(stuffDataPath, 'utf8', (err, data) => {
          if (err) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ success: false, error: 'Stuff file not found' }));
          }

          try {
            let stuff = JSON.parse(data);
            
            // Find and remove the stuff matching URL and timestamp
            const initialLength = stuff.length;
            const timestampNum = Number(timestamp);
            stuff = stuff.filter(item => !(item.url === url && Number(item.timestamp) === timestampNum));
            
            if (stuff.length === initialLength) {
              res.writeHead(404, { 'Content-Type': 'application/json' });
              return res.end(JSON.stringify({ success: false, error: 'Video not found' }));
            }

            // Write back to file
            fs.writeFile(stuffDataPath, JSON.stringify(stuff, null, 2), (writeErr) => {
              if (writeErr) {
                res.writeHead(500, { 'Content-Type': 'application/json' });
                return res.end(JSON.stringify({ success: false, error: 'Failed to delete video' }));
              }

              res.writeHead(200, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ success: true, message: 'Video deleted successfully' }));
            });
          } catch (parseErr) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ success: false, error: 'Error parsing stuff data' }));
          }
        });
      } catch (parseErr) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: 'Invalid JSON data' }));
      }
    });
    return;
  }

  // --- SERVE STUFF IMAGES ---
  if (req.url.startsWith('/stuff/image/') && req.method === 'GET') {
    let filename = req.url.replace('/stuff/image/', '');
    // Decode URL-encoded filename
    try {
      filename = decodeURIComponent(filename);
    } catch (e) {
      // If decoding fails, use as-is
    }
    
    // Security: validate filename (no path traversal)
    if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
      res.writeHead(400);
      return res.end('Invalid filename');
    }

    const homeDir = os.homedir();
    const imagePath = path.join(homeDir, 'Pictures', 'Stuff', filename);

    fs.readFile(imagePath, (err, data) => {
      if (err) {
        res.writeHead(404);
        return res.end('Image not found');
      }

      const ext = path.extname(filename).toLowerCase();
      const mime = {
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.png': 'image/png',
        '.gif': 'image/gif',
        '.webp': 'image/webp',
        '.bmp': 'image/bmp',
        '.svg': 'image/svg+xml'
      }[ext] || 'image/jpeg';

      res.writeHead(200, { 
        'Content-Type': mime,
        'Cache-Control': 'public, max-age=31536000'
      });
      res.end(data);
    });
    return;
  }

  // --- STUFF PREVIEW IMAGE ENDPOINT (for most recent post) ---
  if ((req.url === '/stuff/preview' || req.url === '/stuff/thumbnail') && req.method === 'GET') {
    const stuffDataPath = path.join(__dirname, 'stuff.json');
    
    fs.readFile(stuffDataPath, 'utf8', (err, data) => {
      if (err) {
        // If file doesn't exist or error, return a default image or 404
        res.writeHead(404);
        return res.end('No preview available');
      }

      try {
        const stuff = JSON.parse(data);
        
        if (!stuff || stuff.length === 0) {
          res.writeHead(404);
          return res.end('No stuff available');
        }

        // Sort by timestamp, newest first
        stuff.sort((a, b) => b.timestamp - a.timestamp);
        const mostRecent = stuff[0];
        const isYouTube = mostRecent.isYouTube !== false;
        const itemUrl = mostRecent.url || '';
        const imageUrl = mostRecent.imageUrl || '';

        // If it's a YouTube video, get YouTube thumbnail
        if (isYouTube && itemUrl) {
          // Extract video ID from various YouTube URL formats
          let videoId = null;
          
          // Format: https://www.youtube.com/watch?v=VIDEO_ID
          const watchMatch = itemUrl.match(/[?&]v=([^&]+)/);
          if (watchMatch) {
            videoId = watchMatch[1];
          }
          
          // Format: https://youtu.be/VIDEO_ID
          if (!videoId) {
            const shortMatch = itemUrl.match(/youtu\.be\/([^?&]+)/);
            if (shortMatch) {
              videoId = shortMatch[1];
            }
          }
          
          // Format: https://www.youtube.com/embed/VIDEO_ID
          if (!videoId) {
            const embedMatch = itemUrl.match(/\/embed\/([^?&]+)/);
            if (embedMatch) {
              videoId = embedMatch[1];
            }
          }

          if (videoId) {
            // Fetch thumbnail from YouTube CDN
            const thumbnailUrl = `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;
            
            https.get(thumbnailUrl, (thumbRes) => {
              if (thumbRes.statusCode === 200) {
                res.writeHead(200, { 
                  'Content-Type': 'image/jpeg',
                  'Cache-Control': 'public, max-age=3600' // Cache for 1 hour
                });
                thumbRes.pipe(res);
              } else {
                // Fallback to hqdefault if maxresdefault doesn't exist
                const fallbackUrl = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
                https.get(fallbackUrl, (fallbackRes) => {
                  if (fallbackRes.statusCode === 200) {
                    res.writeHead(200, { 
                      'Content-Type': 'image/jpeg',
                      'Cache-Control': 'public, max-age=3600'
                    });
                    fallbackRes.pipe(res);
                  } else {
                    res.writeHead(404);
                    res.end('Thumbnail not found');
                  }
                }).on('error', () => {
                  res.writeHead(404);
                  res.end('Error fetching thumbnail');
                });
              }
            }).on('error', () => {
              res.writeHead(404);
              res.end('Error fetching thumbnail');
            });
            return;
          }
        }

        // If it's not YouTube and has an imageUrl, serve that image
        if (!isYouTube && imageUrl) {
          // Check if it's a local uploaded image
          if (imageUrl.startsWith('/stuff/image/')) {
            const filename = imageUrl.replace('/stuff/image/', '');
            try {
              const decodedFilename = decodeURIComponent(filename);
              
              // Security: validate filename (no path traversal)
              if (decodedFilename.includes('..') || decodedFilename.includes('/') || decodedFilename.includes('\\')) {
                res.writeHead(400);
                return res.end('Invalid filename');
              }

              const homeDir = os.homedir();
              const imagePath = path.join(homeDir, 'Pictures', 'Stuff', decodedFilename);

              fs.readFile(imagePath, (err, imageData) => {
                if (err) {
                  res.writeHead(404);
                  return res.end('Image not found');
                }

                const ext = path.extname(decodedFilename).toLowerCase();
                const mime = {
                  '.jpg': 'image/jpeg',
                  '.jpeg': 'image/jpeg',
                  '.png': 'image/png',
                  '.gif': 'image/gif',
                  '.webp': 'image/webp',
                  '.bmp': 'image/bmp',
                  '.svg': 'image/svg+xml'
                }[ext] || 'image/jpeg';

                res.writeHead(200, { 
                  'Content-Type': mime,
                  'Cache-Control': 'public, max-age=3600'
                });
                res.end(imageData);
              });
              return;
            } catch (e) {
              res.writeHead(404);
              return res.end('Error reading image');
            }
          } else {
            // It's an external URL, proxy it
            try {
              const parsedUrl = new URL(imageUrl);
              const protocol = parsedUrl.protocol === 'https:' ? https : http;
              const options = {
                hostname: parsedUrl.hostname,
                port: parsedUrl.port || (parsedUrl.protocol === 'https:' ? 443 : 80),
                path: parsedUrl.pathname + parsedUrl.search,
                headers: {
                  'User-Agent': 'Mozilla/5.0 (compatible; ThinkPadClub/1.0)'
                }
              };
              
              protocol.get(options, (imageRes) => {
                if (imageRes.statusCode === 200) {
                  res.writeHead(200, { 
                    'Content-Type': imageRes.headers['content-type'] || 'image/jpeg',
                    'Cache-Control': 'public, max-age=3600'
                  });
                  imageRes.pipe(res);
                } else {
                  res.writeHead(404);
                  res.end('Image not found');
                }
              }).on('error', () => {
                res.writeHead(404);
                res.end('Error fetching image');
              });
              return;
            } catch (e) {
              res.writeHead(404);
              return res.end('Invalid image URL');
            }
          }
        }

        // No image available
        res.writeHead(404);
        res.end('No preview available');
      } catch (parseErr) {
        res.writeHead(500);
        res.end('Error parsing stuff data');
      }
    });
    return;
  }

  // --- STUFF PAGE (view-only) ---
  if (req.url === '/stuff' && req.method === 'GET') {
    const stuffPagePath = path.join(__dirname, 'stuff.html');
    fs.readFile(stuffPagePath, (err, data) => {
      if (err) {
        res.writeHead(404);
        return res.end('Stuff page not found');
      }
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(data);
    });
    return;
  }

  // --- ADD STUFF PAGE ---
  if (req.url === '/stuff/add' && req.method === 'GET') {
    const addStuffPagePath = path.join(__dirname, 'add-stuff.html');
    fs.readFile(addStuffPagePath, (err, data) => {
      if (err) {
        res.writeHead(404);
        return res.end('Add stuff page not found');
      }
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(data);
    });
    return;
  } else {

    // --- STATIC FILE SERVER (includes index.html) ---
    const requestedPath = req.url === '/' ? '/index.html' : req.url;
    // Remove query string and hash for file path resolution
    const urlPath = requestedPath.split('?')[0].split('#')[0];
    // Remove leading slash and join with __dirname
    const normalizedPath = urlPath.startsWith('/') ? urlPath.slice(1) : urlPath;
    const filePath = path.join(__dirname, normalizedPath);
    
    // Security: ensure file is within __dirname (prevent path traversal)
    const resolvedPath = path.resolve(filePath);
    const resolvedDir = path.resolve(__dirname);
    if (!resolvedPath.startsWith(resolvedDir)) {
      res.writeHead(403);
      return res.end('Forbidden');
    }

    fs.readFile(filePath, (err, data) => {
      if (err) {
        res.writeHead(404);
        return res.end('Not found');
      }

      // Get MIME type from URL path (before query string) for accurate detection
      const ext = path.extname(urlPath).toLowerCase();
      let mime = {
        '.png': 'image/png',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.gif': 'image/gif',
        '.svg': 'image/svg+xml',
        '.webp': 'image/webp',
        '.bmp': 'image/bmp',
        '.html': 'text/html; charset=utf-8',
        '.css': 'text/css; charset=utf-8',
        '.js': 'application/javascript; charset=utf-8',
        '.txt': 'text/plain; charset=utf-8'
      }[ext];
      
      if (!mime) {
        console.log(`Warning: Unknown file extension "${ext}" for ${urlPath}, using application/octet-stream`);
        mime = 'application/octet-stream';
      } else {
        console.log(`Serving ${urlPath} with MIME type: ${mime}`);
      }

      res.writeHead(200, { 'Content-Type': mime });
      res.end(data);
    });
  }
});

// --- START SERVER ---
server.listen(3000, () => console.log('Running on port 3000'));
