// Handle print form submission
document.getElementById('printForm').addEventListener('submit', function(e) {
  e.preventDefault();
  
  const formData = new FormData();
  const file = document.getElementById('printFile').files[0];
  const printerName = document.getElementById('printerName').value.trim();
  
  if (!file) {
    document.getElementById('printStatus').textContent = 'Please select a file.';
    return;
  }

  formData.append('file', file);
  if (printerName) {
    formData.append('printer', printerName);
  }

  const status = document.getElementById('printStatus');
  status.textContent = 'Printing...';

  fetch('/print', {
    method: 'POST',
    body: formData
  })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        status.textContent = `Print job sent! ${data.message || ''}`;
        document.getElementById('printForm').reset();
      } else {
        status.textContent = `Error: ${data.error || 'Failed to print'}`;
      }
    })
    .catch(error => {
      status.textContent = `Error: ${error.message}`;
    });
});

function captureWebcam() {
  const btn = document.getElementById('captureBtn');
  const status = document.getElementById('captureStatus');
  const webcamImg = document.getElementById('webcamImage');
  btn.disabled = true;
  if (status) {
    status.textContent = 'Capturing...';
  }
  
  fetch('/capture')
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        if (status) {
          status.textContent = `Captured! Saved as ${data.filename}`;
        }
        // Wait a moment for the file to be fully written, then refresh with cache busting
        setTimeout(() => {
          webcamImg.src = '/webcam/current.jpg?t=' + new Date().getTime();
          webcamImg.style.display = 'block';
          const webcamStatus = document.getElementById('webcamStatus');
          if (webcamStatus) {
            webcamStatus.textContent = '';
          }
        }, 500); // 500ms delay to ensure file is written
      } else {
        if (status) {
          status.textContent = `Error: ${data.error || 'Failed to capture'}`;
        }
      }
      btn.disabled = false;
    })
    .catch(error => {
      if (status) {
        status.textContent = `Error: ${error.message}`;
      }
      btn.disabled = false;
    });
}
