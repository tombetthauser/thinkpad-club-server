const http = require('http');
const fs = require('fs');
const path = require('path');

// --- Binary-safe multipart parser ---
function parseMultipart(req, boundary, callback) {
  const chunks = [];
  req.on('data', chunk => chunks.push(chunk));
  req.on('end', () => {
    const buffer = Buffer.concat(chunks);
    const boundaryBuffer = Buffer.from(boundary);
    const parts = [];

    let start = buffer.indexOf(boundaryBuffer);
    if (start === -1) return callback({ filename: null, fileBuffer: null });

    while (start !== -1) {
      const end = buffer.indexOf(boundaryBuffer, start + boundaryBuffer.length);
      if (end === -1) break;
      parts.push(buffer.slice(start + boundaryBuffer.length, end));
      start = end;
    }

    let filename = null;
    let fileBuffer = null;

    parts.forEach(part => {
      const headerEnd = part.indexOf('\r\n\r\n');
      if (headerEnd === -1) return;

      const header = part.slice(0, headerEnd).toString();
      const body = part.slice(headerEnd + 4, part.length - 2); // remove trailing CRLF

      if (header.includes('name="filename"')) {
        filename = body.toString().trim();
      }
      if (header.includes('name="file"')) {
        fileBuffer = body; // keep as binary
      }
    });

    callback({ filename, fileBuffer });
  });
}

// --- HTTP SERVER ---
const server = http.createServer((req, res) => {
  if (req.url === '/' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(`
      <html>
        <head>
          <meta property="og:title" content="ThinkPad Club Mini-Server! 💿"/>
          <meta property="og:image" content="https://mini-server.<your-domain>.com/server.png"/>
          <meta name="theme-color" content="#000000"/>
          <style>
            body { width: 500px; margin-bottom: 50px; font-size: 20px; }
            h1 { font-size: 80px; font-weight: 100; }
            img { width: 100%; }
            @media (max-width: 812px), (max-device-width: 812px) {
                body { width: 100%; font-size: 40px; }
                h1 { font-size: 160px; font-weight: 100; }
            }
          </style>
        </head>
        <body>
          <h1>Welcome to ThinkPad Club! hello!</h1>

          <p><b>Upload an image to this server:</b></p>
          <form action="/upload" method="POST" enctype="multipart/form-data">
            <input type="text" name="filename" placeholder="image.png" required />
            <br/><br/>
            <input type="file" name="file" accept="image/*" required />
            <br/><br/>
            <button type="submit">Upload</button>
          </form>

          <p>This website is running on a server the size of a cracker! It can work anywhere where there's an internet connection. It starts up automatically after you plug it in somewhere. If you unplug it the website disappears from the internet!.</p>
          <img src="/server-2.jpeg"/>

	  <h2> here are some things from the thinkpad club...</h2>
          <p>for the record they wrote all this in nano directly in the pi terminal...</p>
          <ul>
            <li>This is a coding website.</li>
            <li>HI MOM I AM CODING FOR 99999999 MINUTES STRAIGHT GETME HOME NOW!!!!!!!!!!!!!!!!!!!!-sINGED, t rIsTAN</li>
            <li>This club contain 9 people YAY!!!!!!!!!!!!!!!!!</li>
            <li>These are being typed by the coding club students.</li>
            <li>buy the letter A for 100000000000 dollars and 99 cents hahaha 67 -Kingston Toure</li>
          </ul>

          <img src="/cute-cat.jpg"/>
          <p>This is the website for the ThinkPad computer club...</p>

          <a href="https://tombetthauser.github.io/thinkpad-club/">/old-thinkpad-club-website</a>
        </body>
      </html>
    `);

  } else if (req.url === '/upload' && req.method === 'POST') {
    const contentType = req.headers['content-type'];
    const boundaryMatch = contentType.match(/boundary=(.+)$/);

    if (!boundaryMatch) {
      res.writeHead(400);
      return res.end('No multipart boundary found.');
    }

    const boundary = '--' + boundaryMatch[1];

    parseMultipart(req, boundary, ({ filename, fileBuffer }) => {
      if (!filename || !fileBuffer) {
        res.writeHead(400);
        return res.end('Missing filename or file data.');
      }

      const savePath = path.join(__dirname, filename);

      fs.writeFile(savePath, fileBuffer, err => {
        if (err) {
          res.writeHead(500);
          return res.end('Failed to save file.');
        }

        res.writeHead(200);
        res.end(`Upload successful! Saved as ${filename}`);
      });
    });

  } else {
    // --- STATIC FILE SERVER ---
    const filePath = path.join(__dirname, req.url);

    fs.readFile(filePath, (err, data) => {
      if (err) {
        res.writeHead(404);
        return res.end('Not found');
      }

      const ext = path.extname(filePath).toLowerCase();
      const mime = {
        '.png': 'image/png',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.gif': 'image/gif',
        '.svg': 'image/svg+xml',
        '.webp': 'image/webp',
        '.bmp': 'image/bmp',
        '.html': 'text/html',
        '.txt': 'text/plain'
      }[ext] || 'application/octet-stream';

      res.writeHead(200, { 'Content-Type': mime });
      res.end(data);
    });
  }
});

// --- START SERVER ---
server.listen(3000, () => console.log('Running on port 3000'));
