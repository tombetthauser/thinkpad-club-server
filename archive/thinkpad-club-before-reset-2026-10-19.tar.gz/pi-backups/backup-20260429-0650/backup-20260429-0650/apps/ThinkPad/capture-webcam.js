#!/usr/bin/env node
/**
 * Standalone script to capture an image from USB webcam
 * Saves to current.jpg and archives the previous image
 * Usage: node capture-webcam.js
 */

const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

const homeDir = os.homedir();
const webcamDir = path.join(homeDir, 'Pictures', 'Webcam');
const archiveDir = path.join(webcamDir, 'archive');
const currentImagePath = path.join(webcamDir, 'current.jpg');

// Ensure directories exist
if (!fs.existsSync(webcamDir)) {
  fs.mkdirSync(webcamDir, { recursive: true });
  console.log(`Created directory: ${webcamDir}`);
}
if (!fs.existsSync(archiveDir)) {
  fs.mkdirSync(archiveDir, { recursive: true });
  console.log(`Created directory: ${archiveDir}`);
}

// Archive the old current.jpg if it exists
if (fs.existsSync(currentImagePath)) {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const archiveFilename = `current-${timestamp}.jpg`;
  const archivePath = path.join(archiveDir, archiveFilename);
  
  fs.renameSync(currentImagePath, archivePath);
  console.log(`Archived previous image to ${archivePath}`);
}

// Use fswebcam to capture image directly to current.jpg
// -r 1280x720: resolution (adjust as needed)
// --no-banner: remove timestamp banner
// -S 2: skip 2 frames to let camera adjust
const command = `fswebcam -r 1280x720 --no-banner -S 2 "${currentImagePath}"`;

console.log('Capturing image from webcam...');
exec(command, (error, stdout, stderr) => {
  if (error) {
    console.error(`Error capturing webcam: ${error.message}`);
    if (stderr) console.error(`stderr: ${stderr}`);
    process.exit(1);
  }
  
  console.log(`✅ Successfully captured image: ${currentImagePath}`);
  if (stdout) console.log(stdout);
});

